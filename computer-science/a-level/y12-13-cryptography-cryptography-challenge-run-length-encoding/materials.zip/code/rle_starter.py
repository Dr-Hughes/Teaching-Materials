# rle_starter.py
# Decoding pictures with Python.
# Run this file with the green triangle (or F5), then fill in the TODO parts.

import matplotlib.pyplot as plt
from pictures import MUG, DINOSAUR, MARIO, APPLE, LOCK, GHOST, UK_IRELAND
# ^ that line fetches the clues from the file pictures.py (keep it in the same folder)


# ---------- GIVEN: you do not need to change this function ----------
def show_picture(picture):
    # picture = a list of rows. Each row is a list of 0s (blank) and 1s (coloured).
    plt.imshow(picture, cmap="Greys", interpolation="nearest")
    plt.axis("off")
    plt.show()


# ---------- TEST: a tiny picture made by hand ----------
heart = [
    [0, 1, 0, 1, 0],
    [1, 1, 1, 1, 1],
    [0, 1, 1, 1, 0],
    [0, 0, 1, 0, 0],
]
show_picture(heart)


# ---------- TODO 1: decode ONE row ----------
def decode_row(clue):
    row = []       # the row we are building. It starts empty.
    colour = 0     # we always start with blanks (0)

    # TODO: go through each number in the clue (a for loop over the list).
    #   1. add that many copies of colour to the row
    #      hint: a loop inside a loop: for i in range(number), then row.append(colour)
    #   2. then swap the colour: 0 becomes 1, and 1 becomes 0
    #      hint: an if / else, or the shortcut  colour = 1 - colour

    return row


# Test it. The answer should be [0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0]
print(decode_row([2, 7, 3]))


# ---------- TODO 2: decode a WHOLE picture ----------
def decode_picture(clues):
    picture = []   # the picture we are building. It starts empty.

    # TODO: go through each clue in clues.
    #   1. decode that clue into a row (you already wrote a function for this!)
    #   2. add the row to the picture   hint: picture.append(...)

    return picture


# Test it on the mug, then look at the Plots pane
# show_picture(decode_picture(MUG))


# ---------- TODO 3: try the bigger ones ----------
# show_picture(decode_picture(DINOSAUR))
# show_picture(decode_picture(MARIO))
# show_picture(decode_picture(UK_IRELAND))   # the one that took ages by hand!


# ---------- STRETCH: go backwards (ENCODE) ----------
def encode_row(row):
    clue = []
    # TODO: count how many pixels in a row are the same, and add each count to clue.
    # hints: start by counting blanks (0). Keep a count variable.
    #   if the pixel matches the colour we are counting, count += 1
    #   otherwise, add count to clue, swap the colour, and start counting again.
    #   Don't forget to add the last count when the loop ends!
    return clue

# print(encode_row([0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0]))   # should print [2, 7, 3]
