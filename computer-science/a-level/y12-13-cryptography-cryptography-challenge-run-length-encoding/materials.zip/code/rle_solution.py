# rle_solution.py  (INSTRUCTOR COPY: do not hand out before students have tried)

import matplotlib.pyplot as plt
from pictures import MUG, DINOSAUR, MARIO, APPLE, LOCK, GHOST, UK_IRELAND


def show_picture(picture):
    plt.imshow(picture, cmap="Greys", interpolation="nearest")
    plt.axis("off")
    plt.show()


def decode_row(clue):
    row = []
    colour = 0
    for number in clue:
        for i in range(number):
            row.append(colour)
        if colour == 0:
            colour = 1
        else:
            colour = 0
    return row


def decode_picture(clues):
    picture = []
    for clue in clues:
        row = decode_row(clue)
        picture.append(row)
    return picture


def encode_row(row):
    clue = []
    colour = 0
    count = 0
    for pixel in row:
        if pixel == colour:
            count += 1
        else:
            clue.append(count)
            colour = pixel
            count = 1
    clue.append(count)
    return clue


print(decode_row([2, 7, 3]))
print(encode_row([0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0]))
show_picture(decode_picture(MUG))
show_picture(decode_picture(DINOSAUR))
show_picture(decode_picture(MARIO))
show_picture(decode_picture(APPLE))
show_picture(decode_picture(LOCK))
show_picture(decode_picture(GHOST))
show_picture(decode_picture(UK_IRELAND))
