# image_solution.py  (INSTRUCTOR COPY: do not hand out before students have tried)

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def image_path(number):
    return "cow_message/" + str(number).zfill(2) + ".png"


def show_colour(red, green, blue):
    plt.imshow([[(red, green, blue)]])
    plt.axis("off")
    plt.show()


def total_red(path):
    img = Image.open(path)
    pixels = np.array(img)
    red = pixels[:, :, 0]
    total = red.sum()
    return total


def letter_for(path):
    total = total_red(path)
    position = total % 26
    letter = ALPHABET[position]
    return letter


def decode_message():
    message = ""
    for number in range(1, 38):
        letter = letter_for(image_path(number))
        message += letter
    return message


print(total_red("cow-demo.jpg"))
print(letter_for("cow-demo.jpg"))
print(decode_message())
