# image_starter.py
# Decoding the cow message with Python.
#
# SET UP: put this file in the SAME folder as cow-demo.jpg and the cow_message folder.
# Run it with the green triangle (or F5), then fill in the TODO parts.

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"     # A is 0, B is 1, ... Z is 25


# ---------- GIVEN: you do not need to change these two functions ----------
def image_path(number):
    # image_path(1) gives "cow_message/01.png", image_path(12) gives "cow_message/12.png"
    return "cow_message/" + str(number).zfill(2) + ".png"


def show_colour(red, green, blue):
    # draws one big square of the colour you give it (each number is 0 to 255)
    plt.imshow([[(red, green, blue)]])
    plt.axis("off")
    plt.show()


# ---------- STEP 1: look at a picture (run this and read the output) ----------
img = Image.open("cow-demo.jpg")
pixels = np.array(img)
print("size:", img.size)
print("shape:", pixels.shape)
print("first pixel:", pixels[0, 0])
show_colour(230, 30, 30)       # try changing these three numbers!


# ---------- STEP 2 (TODO): add up all the red in ONE picture ----------
def total_red(path):
    img = Image.open(path)
    pixels = np.array(img)

    # TODO: get just the red channel
    #   hint: pixels[:, :, 0]   (every row, every column, channel 0 = red)
    # TODO: add up every red value in it
    #   hint: .sum()
    # TODO: return that total

    return 0


# Test it. It should print 10218857
print(total_red("cow-demo.jpg"))


# ---------- STEP 3 (TODO): turn a picture into ONE letter ----------
def letter_for(path):
    # TODO: 1. get the red total for this picture (you wrote a function for this!)
    #       2. take it % 26   (the remainder, a number from 0 to 25)
    #       3. use that number to pick a letter from ALPHABET
    #          hint: ALPHABET[2] is "C"
    #       4. return the letter
    return ""


# Test it. It should print Z
print(letter_for("cow-demo.jpg"))


# ---------- STEP 4 (TODO): decode the WHOLE message ----------
def decode_message():
    message = ""       # the message we are building. It starts empty.

    # TODO: for each number from 1 to 37 (hint: for number in range(1, 38))
    #   1. find the picture:  image_path(number)
    #   2. work out its letter (you already wrote a function for this!)
    #   3. stick the letter on the end of message:  message += letter

    return message


# Run it. Does the message make sense? If not, check your steps 2 and 3.
# print(decode_message())


# ---------- STRETCH: a different channel ----------
# What if you add up the GREEN values (channel 1) or BLUE values (channel 2) instead?
# Copy your functions, change the 0, and see what message you get.
