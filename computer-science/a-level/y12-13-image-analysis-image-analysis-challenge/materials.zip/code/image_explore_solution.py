# image_explore_solution.py  (INSTRUCTOR COPY: do not hand out before students have tried)

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt


def show(pixels):
    plt.imshow(pixels)
    plt.axis("off")
    plt.show()


def show_channel(channel, colour):
    plt.imshow(channel, cmap=colour, vmin=0, vmax=255)
    plt.axis("off")
    plt.colorbar()
    plt.show()


def show_colour(red, green, blue):
    # draws one big square of the colour you give it (each number is 0 to 255)
    plt.imshow([[(red, green, blue)]])
    plt.axis("off")
    plt.show()


img = Image.open("cow-demo.jpg")
pixels = np.array(img)
show(pixels)
print(pixels.shape)

print(pixels[0, 0])
print(pixels[100, 200])

corner = pixels[0:100, 0:100]
show(corner)
other_corner = pixels[220:320, 220:320]
show(other_corner)

show_colour(230, 30, 30)
show_colour(255, 255, 0)
show_colour(128, 128, 128)

red = pixels[:, :, 0]
green = pixels[:, :, 1]
blue = pixels[:, :, 2]
show_channel(red, "Reds")
show_channel(green, "Greens")
show_channel(blue, "Blues")

no_red = pixels.copy()
no_red[:, :, 0] = 0
show(no_red)
no_green = pixels.copy()
no_green[:, :, 1] = 0
show(no_green)
no_blue = pixels.copy()
no_blue[:, :, 2] = 0
show(no_blue)
only_blue = pixels.copy()
only_blue[:, :, 0] = 0
only_blue[:, :, 1] = 0
show(only_blue)

grey = np.array(img.convert("L"))
show_channel(grey, "gray")
negative = 255 - pixels
show(negative)

print(grey.mean())
print((grey < 50).sum())
bright = (grey > 100).sum()
print(bright)
print(bright / grey.size)

plt.hist(grey.flatten(), bins=16)
plt.show()
plt.hist(red.flatten(), bins=16)
plt.show()
