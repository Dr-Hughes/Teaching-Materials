# image_explore.py
# Exploring a picture with Python.
#
# SET UP: put this file in the SAME folder as cow-demo.jpg.
# Run the whole file with the green triangle (F5), or run one block at a time
# by selecting it and pressing F9. Each picture appears in the Plots pane.

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt


# ---------- GIVEN: you do not need to change these three functions ----------
def show(pixels):
    # draws a colour picture from a grid of numbers
    plt.imshow(pixels)
    plt.axis("off")
    plt.show()


def show_channel(channel, colour):
    # draws ONE channel, using the colour scale you give: "Reds", "Greens", "Blues" or "gray"
    plt.imshow(channel, cmap=colour, vmin=0, vmax=255)
    plt.axis("off")
    plt.colorbar()
    plt.show()


def show_colour(red, green, blue):
    # draws one big square of the colour you give it (each number is 0 to 255)
    plt.imshow([[(red, green, blue)]])
    plt.axis("off")
    plt.show()


# ---------- TASK 1: open a picture ----------
img = Image.open("cow-demo.jpg")
pixels = np.array(img)
show(pixels)
print(pixels.shape)          # predict first: how many rows? how many columns?


# ---------- TASK 2: one pixel ----------
print(pixels[0, 0])          # the pixel in row 0, column 0 (top left)
# TODO: print the pixel in row 100, column 200
#   hint: pixels[row, column]


# ---------- TASK 3: crop a corner ----------
corner = pixels[0:100, 0:100]      # rows 0 to 99, columns 0 to 99
show(corner)
# TODO: crop a different 100 x 100 square, then show it
#   hint: change the numbers, keep the colon and the comma


# ---------- TRY IT: mix a colour (after the RGB slides) ----------
show_colour(230, 30, 30)       # red, green, blue. Try changing these three numbers!
# TODO: make yellow, then make a grey


# ---------- TASK 4: split the channels ----------
red = pixels[:, :, 0]
show_channel(red, "Reds")
# TODO: do the same for green (channel 1) and blue (channel 2)
#   hint: show_channel(green, "Greens")
# Which channel is brightest on the wall? Which is brightest on the cow?


# ---------- TASK 5: switch a channel off ----------
no_red = pixels.copy()             # .copy() makes a second picture to change
no_red[:, :, 0] = 0                # set every red value to 0
show(no_red)
# TODO: make a picture with NO green, and one with NO blue
# TODO: make a picture that is ONLY blue (red and green both 0)


# ---------- TASK 6: grey and negative ----------
grey = np.array(img.convert("L"))  # "L" means one brightness number per pixel
show_channel(grey, "gray")
negative = 255 - pixels            # flips every number: 0 becomes 255, 255 becomes 0
show(negative)


# ---------- TASK 7: count and average ----------
print(grey.mean())                 # the average brightness, 0 to 255
print((grey < 50).sum())           # how many pixels are darker than 50?
# TODO: how many pixels are brighter than 100?
#   hint: change the < and the number
# TODO: what fraction of the whole picture is that?
#   hint: divide by grey.size


# ---------- TASK 8: a histogram ----------
plt.hist(grey.flatten(), bins=16)
plt.show()
# TODO: draw a histogram of just the red channel: plt.hist(red.flatten(), bins=16)


# ---------- STRETCH ----------
# Mirror the picture:  show(pixels[:, ::-1])   # ::-1 means "go backwards"
# Upside down:         show(pixels[::-1])
# Brighten it: add 60 to every number. Careful, what happens above 255?
